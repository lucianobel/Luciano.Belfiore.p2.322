package config;

public final class AppConfig {
    public static final String RUTA_CSV = "src/resources/data/casos.csv";
    public static final String RUTA_BIN = "src/resources/data/casos.dat";

    private AppConfig() {}
}
