package servis;

import model.CasoHawkins;
import model.ClasificacionCaso;
import persistencia.RegistroHawkins;

import java.util.List;

public class CasoService {

    private RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();

    public void agregarCaso(CasoHawkins c) {
        registro.agregar(c);
    }

    public List<CasoHawkins> filtrarPorClasificacion(ClasificacionCaso clasif) {
        return registro.filtrar(c -> c.getClasificacion() == clasif);
    }

    public List<CasoHawkins> filtrarPorTitulo(String palabra) {
        return registro.filtrar(c -> c.getTitulo().toLowerCase().contains(palabra.toLowerCase()));
    }

    public void ordenarPorId() {
        registro.ordenarNatural();
    }

    public List<CasoHawkins> obtenerTodos() {
        return registro.getTodos();
    }
}

