package persistencia;

import model.CSVSerializable;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class RegistroHawkins<T extends CSVSerializable & Serializable & Comparable<T>> implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<T> lista = new ArrayList<>();

    private transient Function<String, T> csvParser;

    public RegistroHawkins() {}

    public RegistroHawkins(Function<String, T> csvParser) {
        this.csvParser = csvParser;
    }

    public void setCsvParser(Function<String, T> csvParser) {
        this.csvParser = csvParser;
    }

    public void agregar(T obj) {
        lista.add(obj);
    }

    public T obtener(int index) {
        return lista.get(index);
    }

    public T eliminar(int index) {
        return lista.remove(index);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        lista.forEach(accion);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : lista) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public void ordenarNatural() {
        lista.sort(null);
    }

    public void ordenar(Comparator<T> cmp) {
        lista.sort(cmp);
    }

    public List<T> getTodos() {
        return List.copyOf(lista);
    }

    public void guardarEnArchivo(String ruta) throws IOException {
        File f = new File(ruta);
        f.getParentFile().mkdirs();
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(f))) {
            out.writeObject(lista);
        }
    }

    @SuppressWarnings("unchecked")
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        File f = new File(ruta);
        if (!f.exists()) {
            lista = new ArrayList<>();
            return;
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f))) {
            lista = (List<T>) in.readObject();
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
        File f = new File(ruta);
        f.getParentFile().mkdirs();
        try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
            for (T obj : lista) {
                pw.println(obj.toCSV());
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> parser) throws IOException {
        this.csvParser = parser;
        lista.clear();
        File f = new File(ruta);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                T elem = csvParser.apply(linea);
                lista.add(elem);
            }
        }
    }

    public void agregarDesdeCSV(String linea) {
        if (csvParser == null) {
            throw new IllegalStateException("No se definió csvParser. Usa cargarDesdeCSV(ruta, parser) o setCsvParser(...) antes.");
        }
        T elem = csvParser.apply(linea);
        lista.add(elem);
    }
}
